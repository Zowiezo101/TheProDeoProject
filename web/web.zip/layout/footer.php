	<div class="footer">
		<?php echo $Footer["PP_Name"]; ?>
	</div>
</body>