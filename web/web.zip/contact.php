<!DOCTYPE html>
<html>
	<?php require "layout/header.php"; ?>
	
	<div>
		<h1><?php echo $Content["tbd"]; ?></h1>
	</div>
	
	<?php require "layout/footer.php" ?>
</html>