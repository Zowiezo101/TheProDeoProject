<!DOCTYPE html>
<html>
	<?php require "layout/header.php"; ?>
	
	<!-- Important, do something with sessions here!! -->
	<div class="clearfix">
		<div class="contents_left" id="settings">
			<h1><?php echo $Content["tbd"]; ?></h1>
		</div>
		
		<div class="contents_right" id="settings">
			<h1><?php echo $Content["tbd"]; ?></h1>
		</div>
	</div>
	
	<?php require "layout/footer.php" ?>
</html>